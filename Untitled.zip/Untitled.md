```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.discrete.discrete_model import Logit
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.model_selection import train_test_split
import statsmodels.tools as sm
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix, recall_score, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV,cross_val_score
import scikitplot as skplt 
import warnings
warnings.filterwarnings('ignore')
```


    ---------------------------------------------------------------------------

    ModuleNotFoundError                       Traceback (most recent call last)

    <ipython-input-76-4431f35e8e26> in <module>
         12 from sklearn.ensemble import RandomForestClassifier
         13 from sklearn.model_selection import GridSearchCV,cross_val_score
    ---> 14 import scikitplot as skplt
         15 import warnings
         16 warnings.filterwarnings('ignore')
    

    ModuleNotFoundError: No module named 'scikitplot'



```python
url="https://raw.githubusercontent.com/aniharutyunyan1/Bus1234/master/CRA_client_data%202.csv"
data=pd.read_csv(url)
```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 58188 entries, 0 to 58187
    Columns: 143 entries, STATE_CD to CLIENT_ID
    dtypes: float64(3), int64(128), object(12)
    memory usage: 60.8+ MB
    


```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ZIP_CD</th>
      <th>DEM05</th>
      <th>DEM10</th>
      <th>SCR16</th>
      <th>BKRPT_RCV_SCORE_VALUE</th>
      <th>SCR02</th>
      <th>SMARTV40_AAL01</th>
      <th>SMARTV40_AAL02</th>
      <th>SMARTV40_AAL06</th>
      <th>SMARTV40_AAL07</th>
      <th>...</th>
      <th>BRC5231T</th>
      <th>BRC5530T</th>
      <th>BRC5531T</th>
      <th>BRC8131T</th>
      <th>XFC06</th>
      <th>XFC07</th>
      <th>DECILE</th>
      <th>EXP_ID</th>
      <th>RESPONSE_FLAG</th>
      <th>CLIENT_ID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>0.0</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>...</td>
      <td>5.818800e+04</td>
      <td>5.818800e+04</td>
      <td>5.818800e+04</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>0.0</td>
      <td>58188.000000</td>
      <td>58188.000000</td>
      <td>58188.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>48503.835499</td>
      <td>10.509710</td>
      <td>NaN</td>
      <td>629.502028</td>
      <td>285.474067</td>
      <td>750.428594</td>
      <td>23.693373</td>
      <td>11.692222</td>
      <td>12.504193</td>
      <td>10.904998</td>
      <td>...</td>
      <td>2.437413e+05</td>
      <td>2.457344e+05</td>
      <td>2.456153e+05</td>
      <td>3.441380</td>
      <td>1.743040</td>
      <td>0.155255</td>
      <td>NaN</td>
      <td>80.136179</td>
      <td>0.166667</td>
      <td>53.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>30823.041620</td>
      <td>10.496808</td>
      <td>NaN</td>
      <td>59.153490</td>
      <td>161.227238</td>
      <td>242.883966</td>
      <td>12.203782</td>
      <td>6.121272</td>
      <td>6.397817</td>
      <td>5.800581</td>
      <td>...</td>
      <td>1.550949e+07</td>
      <td>1.550946e+07</td>
      <td>1.550946e+07</td>
      <td>5.929593</td>
      <td>2.694051</td>
      <td>0.591608</td>
      <td>NaN</td>
      <td>9.166588</td>
      <td>0.372681</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1001.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>391.000000</td>
      <td>1.000000</td>
      <td>179.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>2.050000e+02</td>
      <td>2.050000e+02</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>68.000000</td>
      <td>0.000000</td>
      <td>53.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>21043.000000</td>
      <td>2.000000</td>
      <td>NaN</td>
      <td>598.000000</td>
      <td>171.750000</td>
      <td>659.000000</td>
      <td>15.000000</td>
      <td>7.000000</td>
      <td>8.000000</td>
      <td>7.000000</td>
      <td>...</td>
      <td>1.675000e+03</td>
      <td>2.855000e+03</td>
      <td>2.784000e+03</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>72.000000</td>
      <td>0.000000</td>
      <td>53.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>40475.000000</td>
      <td>7.000000</td>
      <td>NaN</td>
      <td>642.000000</td>
      <td>294.000000</td>
      <td>743.000000</td>
      <td>22.000000</td>
      <td>10.000000</td>
      <td>11.000000</td>
      <td>10.000000</td>
      <td>...</td>
      <td>2.509000e+03</td>
      <td>4.271000e+03</td>
      <td>4.165000e+03</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>76.000000</td>
      <td>0.000000</td>
      <td>53.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>78213.000000</td>
      <td>16.000000</td>
      <td>NaN</td>
      <td>675.000000</td>
      <td>399.000000</td>
      <td>828.000000</td>
      <td>30.000000</td>
      <td>15.000000</td>
      <td>16.000000</td>
      <td>14.000000</td>
      <td>...</td>
      <td>3.854000e+03</td>
      <td>6.419000e+03</td>
      <td>6.264000e+03</td>
      <td>4.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>88.000000</td>
      <td>0.000000</td>
      <td>53.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>99901.000000</td>
      <td>69.000000</td>
      <td>NaN</td>
      <td>720.000000</td>
      <td>866.000000</td>
      <td>9999.000000</td>
      <td>155.000000</td>
      <td>67.000000</td>
      <td>73.000000</td>
      <td>66.000000</td>
      <td>...</td>
      <td>1.000000e+09</td>
      <td>1.000000e+09</td>
      <td>1.000000e+09</td>
      <td>98.000000</td>
      <td>54.000000</td>
      <td>28.000000</td>
      <td>NaN</td>
      <td>96.000000</td>
      <td>1.000000</td>
      <td>53.0</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 131 columns</p>
</div>




```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATE_CD</th>
      <th>ZIP_CD</th>
      <th>SEGMENT_CODE</th>
      <th>DEM03</th>
      <th>DEM05</th>
      <th>DEM06</th>
      <th>DEM07</th>
      <th>DEM08</th>
      <th>DEM09</th>
      <th>DEM10</th>
      <th>...</th>
      <th>BRC5530T</th>
      <th>BRC5531T</th>
      <th>BRC8131T</th>
      <th>XFC06</th>
      <th>XFC07</th>
      <th>DECILE</th>
      <th>KEYID</th>
      <th>EXP_ID</th>
      <th>RESPONSE_FLAG</th>
      <th>CLIENT_ID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NJ</td>
      <td>7110</td>
      <td>B</td>
      <td>F</td>
      <td>10</td>
      <td>Y</td>
      <td>H</td>
      <td>I</td>
      <td>S</td>
      <td>NaN</td>
      <td>...</td>
      <td>13424</td>
      <td>13360</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>07110112PP300</td>
      <td>88</td>
      <td>0.0</td>
      <td>53</td>
    </tr>
    <tr>
      <th>1</th>
      <td>MA</td>
      <td>2359</td>
      <td>B</td>
      <td>M</td>
      <td>5</td>
      <td>Y</td>
      <td>H</td>
      <td>G</td>
      <td>S</td>
      <td>NaN</td>
      <td>...</td>
      <td>4560</td>
      <td>4548</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>NaN</td>
      <td>0235960VAC640</td>
      <td>92</td>
      <td>0.0</td>
      <td>53</td>
    </tr>
    <tr>
      <th>2</th>
      <td>FL</td>
      <td>33433</td>
      <td>A</td>
      <td>F</td>
      <td>0</td>
      <td>Y</td>
      <td>P</td>
      <td>I</td>
      <td>A</td>
      <td>NaN</td>
      <td>...</td>
      <td>3581</td>
      <td>3665</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>NaN</td>
      <td>334337170S320</td>
      <td>92</td>
      <td>0.0</td>
      <td>53</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NM</td>
      <td>87123</td>
      <td>A</td>
      <td>F</td>
      <td>12</td>
      <td>Y</td>
      <td>R</td>
      <td>L</td>
      <td>S</td>
      <td>NaN</td>
      <td>...</td>
      <td>1127</td>
      <td>1072</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>NaN</td>
      <td>87123436GN635</td>
      <td>84</td>
      <td>0.0</td>
      <td>53</td>
    </tr>
    <tr>
      <th>4</th>
      <td>IN</td>
      <td>47598</td>
      <td>A</td>
      <td>M</td>
      <td>4</td>
      <td>Y</td>
      <td>H</td>
      <td>D</td>
      <td>S</td>
      <td>NaN</td>
      <td>...</td>
      <td>7599</td>
      <td>7366</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>NaN</td>
      <td>475981467L563</td>
      <td>84</td>
      <td>0.0</td>
      <td>53</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 143 columns</p>
</div>




```python
print("Duplicates:", data.duplicated().sum())
print("Missing values:", data.isna().sum().sum())
print("Single valued columns:", data.columns[data.nunique()==1])
```

    Duplicates: 0
    Missing values: 116393
    Single valued columns: Index(['SMARTV40_APR14', 'CLIENT_ID'], dtype='object')
    


```python
data.isnull().any()
```




    STATE_CD         False
    ZIP_CD           False
    SEGMENT_CODE     False
    DEM03            False
    DEM05            False
                     ...  
    DECILE            True
    KEYID            False
    EXP_ID           False
    RESPONSE_FLAG    False
    CLIENT_ID        False
    Length: 143, dtype: bool




```python
categorical_colnames=data.select_dtypes(include="object").columns
for colname in categorical_colnames:
    val_count=data[colname].value_counts()
    print(colname,"\n",val_count,"\n","\n")
    print("--------------------")
```

    STATE_CD 
     CA    9008
    TX    6841
    FL    6616
    NY    5399
    NJ    3352
    PA    2771
    NC    2219
    OH    2146
    VA    2117
    MI    2010
    MD    1695
    MA    1599
    AZ    1468
    TN    1342
    IN    1189
    MO    1070
    WI     911
    NV     900
    AL     868
    KY     813
    OK     659
    AR     545
    MS     482
    HI     413
    NE     391
    NM     339
    ID     258
    AK     175
    DC     163
    SD     151
    NH     148
    MT     130
    Name: STATE_CD, dtype: int64 
     
    
    --------------------
    SEGMENT_CODE 
     A    24141
    B    14802
    F     7844
    C     5776
    G     2183
    D     1244
    E     1140
    H     1058
    Name: SEGMENT_CODE, dtype: int64 
     
    
    --------------------
    DEM03 
     M    27863
    F    27616
    U     2671
    B       38
    Name: DEM03, dtype: int64 
     
    
    --------------------
    DEM06 
     U    26417
    Y    23013
    N     8758
    Name: DEM06, dtype: int64 
     
    
    --------------------
    DEM07 
     H    31324
    U    11318
    T     7336
    P     4790
    R     3420
    Name: DEM07, dtype: int64 
     
    
    --------------------
    DEM08 
     E    11824
    F    10151
    D     6569
    G     6553
    H     4877
    C     3434
    A     2945
    B     2858
    L     2570
    I     2370
    J     2013
    K     1947
    U       60
    Name: DEM08, dtype: int64 
     
    
    --------------------
    DEM09 
     S    42662
    A     8809
    U     6106
    M      510
    P      101
    Name: DEM09, dtype: int64 
     
    
    --------------------
    SMARTV40_AAU19 
     0    12112
    7     9812
    5     5546
    4     5259
    6     4972
    3     3434
    D     2625
    E     2392
    G     2257
    C     2235
    8     2083
    F     1668
    2     1558
    B     1394
    A      321
    H      299
    1      196
    U       24
    9        1
    Name: SMARTV40_AAU19, dtype: int64 
     
    
    --------------------
    SMARTV40_AAU20 
     7    25080
    0    12112
    E    10172
    6     2571
    5     2075
    3      860
    4      855
    B      839
    C      744
    A      743
    2      731
    D      717
    1      689
    Name: SMARTV40_AAU20, dtype: int64 
     
    
    --------------------
    SMARTV40_AAU22 
     B    13215
    0    12112
    9     6573
    8     4913
    5     4132
    4     3531
    6     3425
    7     3355
    3     3197
    2     2020
    1     1706
    A        9
    Name: SMARTV40_AAU22, dtype: int64 
     
    
    --------------------
    SMARTV40_ALE21 
     0    46054
    B     4955
    9     1337
    5     1065
    8     1030
    4      822
    7      804
    6      796
    3      747
    2      360
    1      213
    A        5
    Name: SMARTV40_ALE21, dtype: int64 
     
    
    --------------------
    KEYID 
     212267933C563    2
    937034034C520    2
    852088832B416    2
    54016928VF616    2
    37188321HS415    2
                    ..
    328298333E430    1
    850221659K630    1
    08540465MR562    1
    460562445D600    1
    530811605S400    1
    Name: KEYID, Length: 58019, dtype: int64 
     
    
    --------------------
    


```python
drops = ["SMARTV40_APR14","CLIENT_ID","SEGMENT_CODE","KEYID","XFC06","XFC07","DECILE","DEM10"]
data = data.drop(drops,axis=1)
```


```python
plt.figure(figsize=(9,5))
sns.countplot(data.RESPONSE_FLAG)
plt.title("RESPONSE")
plt.show()
```


![png](output_9_0.png)



```python
co
```


```python
data.RESPONSE_FLAG.value_counts(normalize=True).mul(100).rename("RESPONSE FLAG percentage")


```




    0.0    83.333333
    1.0    16.666667
    Name: RESPONSE FLAG percentage, dtype: float64




```python
print("Duplicates:", data.duplicated().sum())
print("Missing values:", data.isna().sum().sum())
print("Single valued columns:", data.columns[data.nunique()==1])
```

    Duplicates: 0
    Missing values: 17
    Single valued columns: Index([], dtype='object')
    


```python
numeric_colnames=data.dtypes[data.dtypes=="O"].index.tolist()
rates_list=[]
for colname in numeric_colnames:
    rates=data.groupby(colname)["Attrition"].value_counts(normalize=True).rename("percentage").mul(100).reset_index()
    rates_list.append(rates)
```


```python
rates_list[0]
```


```python
data=pd.get_dummies(data,drop_first=True)

X=data.drop('RESPONSE_FLAG', axis=1)
Y=data.RESPONSE_FLAG
```


```python
X=sm.add_constant(X)
```


```python
X0, X1, Y0, Y1=train_test_split(X,Y, test_size=0.25, random_state=42)
```


```python
train=train.fillna(train.median())
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-72-4efbd2921d57> in <module>
    ----> 1 train=train.fillna(train.median())
    

    NameError: name 'train' is not defined



```python
def make_tree(model):
    tree_0 = model
    tree_0.fit(X0,Y0)
```


```python
Y0_0_proba = tree_0.predict_proba(X0)[:,1] 
Y1_0_proba = tree_0.predict_proba(X1)[:,1] 

Y0_0_class = np.where(Y0_0_proba>0.5,1,0) 
Y1_0_class = np.where(Y1_0_proba>0.5,1,0) 

print("Train ROC AUC by tree_0:",roc_auc_score(Y0,Y0_0_proba))
print("Test ROC AUC by tree_0:",roc_auc_score(Y1,Y1_0_proba))

print("\n")

print("Train Recall by tree_0:",recall_score(Y0,Y0_0_class))
print("Test Recall by tree_0:",recall_score(Y1,Y1_0_class))
```


```python
make_tree(DecisionTreeClassifier(random_state=42)
```


```python
#change the parameters
make_tree(DecisionTreeClassifier(max_depth=7,class_weight="balanced",random_state=42))
```


```python
make_tree(DecisionTreeClassifier(min_samples_leaf=85,random_state=42))
```


```python
make_tree(DecisionTreeClassifier(max_depth=7,min_samples_leaf=85,random_state=42))
```


```python
#BEST Hyperparameters
tree_best = DecisionTreeClassifier(max_depth=7,min_samples_leaf=85,random_state=42)
tree_best.fit(X0,Y0)
```


```python
pd.DataFrame(data=tree_best.feature_importances_,index=X0.columns)
```


```python
tree_final = DecisionTreeClassifier(max_depth=7,min_samples_leaf=85,random_state=42)
tree_final.fit(X0[["satisfaction_level","last_evaluation","number_project","average_montly_hours","time_spend_company"]],Y0)

Y0_best_proba = tree_final.predict_proba(X0[["satisfaction_level","last_evaluation","number_project","average_montly_hours","time_spend_company"]])[:,1]
Y1_best_proba = tree_final.predict_proba(X1[["satisfaction_level","last_evaluation","number_project","average_montly_hours","time_spend_company"]])[:,1]

Y0_best_class = np.where(Y0_best_proba>0.5,1,0)
Y1_best_class = np.where(Y1_best_proba>0.5,1,0)

print("Train ROCAUC:",roc_auc_score(Y0,Y0_best_proba))
print("Test ROCAUC:",roc_auc_score(Y1,Y1_best_proba))
```


```python
plt.figure(figsize=(30,30))
plot_tree(tree_final,filled=True,feature_names=X0.columns)
plt.show()
```


```python

```


```python

```
